import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

public class App {
    public static void main(String[] args) throws Exception {
        String[][][] dataMahasiswa = new String[10][3][3]; // 10 rows and 3 columns

        // Read the CSV file
        try (Reader reader = new FileReader("src/DataMahasiswa.csv")) {
            CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader());

            // Loop through CSV records
            List<CSVRecord> records = csvParser.getRecords();
            for (int i = 0; i < records.size(); i++) {
                CSVRecord record = records.get(i);
                dataMahasiswa[i][0][0] = record.get("Nama");
                dataMahasiswa[i][1][1] = record.get("Kelas");
                dataMahasiswa[i][2][2] = record.get("Npm");
            }
        }

        // Print the filled dataMahasiswa array
        for (int i = 0; i < dataMahasiswa.length; i++) {
            System.out.println("dataMahasiswa[" + i + "][0] = " + dataMahasiswa[i][0][0]);
            System.out.println("dataMahasiswa[" + i + "][1] = " + dataMahasiswa[i][1][1]);
            System.out.println("dataMahasiswa[" + i + "][2] = " + dataMahasiswa[i][2][2]);
        }
    }
}
